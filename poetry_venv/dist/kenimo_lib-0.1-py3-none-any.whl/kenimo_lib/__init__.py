from kenimo_lib.time_print import *
from kenimo_lib.text import * ## ディレクトリ毎importしてしまうと、階層を指定する必要はなくなる
