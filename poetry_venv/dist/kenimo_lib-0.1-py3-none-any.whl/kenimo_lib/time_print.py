import datetime
from kenimo_lib.text import hello

def time_now():
    return datetime.datetime.now()


def same_func_name():
    return "time_print_func"


def hello_from_text():
    return hello()