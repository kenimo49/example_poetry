def hello():
    return "Hello"

def same_func_name():
    return "text_print_func"